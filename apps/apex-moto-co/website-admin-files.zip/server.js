const express = require('express');
const session = require('express-session');
const SQLiteStore = require('connect-sqlite3')(session);
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const path = require('path');
const fs = require('fs');
const dotenv = require('dotenv');
const crypto = require('crypto');
const multer = require('multer');
const { registerDetailingMobileApi } = require('./website-api/detailing-mobile-api');
const { registerWorkshopAuth } = require('./services/workshop-auth');
const storeRoutes = require('./routes/store');

const { logAction } = require('./services/audit');
const { csrfProtection, validateCSRF } = require('./middleware/csrf');
const { requestLogger } = require('./middleware/request-logger');
const {
  contactFormLimiter,
  loginLimiter,
  passwordResetLimiter,
  chatbotLimiter
} = require('./middleware/rate-limiters');

dotenv.config();

const app = express();

if (!process.env.SESSION_SECRET) {
  console.warn('SESSION_SECRET is not configured; sessions will reset when the process restarts.');
}

// ============================================================
// DATABASE
// ============================================================

const db = new sqlite3.Database(
  path.join(__dirname, 'data', 'database.db')
);

const galleryDirectory = path.join(__dirname, 'data', 'gallery');

fs.mkdirSync(galleryDirectory, {
  recursive: true
});

const galleryUpload = multer({
  storage: multer.diskStorage({
    destination: galleryDirectory,
    filename: (req, file, callback) => {
      const extension = path.extname(file.originalname).toLowerCase();

      callback(
        null,
        `${Date.now()}-${crypto.randomBytes(8).toString('hex')}${extension}`
      );
    }
  }),

  fileFilter: (req, file, callback) => {
    if (
      ![
        'image/jpeg',
        'image/png',
        'image/webp',
        'image/gif'
      ].includes(file.mimetype)
    ) {
      return callback(
        new Error(
          'Only JPEG, PNG, WebP and GIF images are supported.'
        )
      );
    }

    callback(null, true);
  },

  limits: {
    fileSize: 10 * 1024 * 1024
  }
});

// ============================================================
// MIDDLEWARE
// ============================================================

app.use(
  express.urlencoded({
    limit: '50mb',
    extended: true
  })
);

app.use(
  express.json({
    limit: '50mb'
  })
);

app.use(express.static('public'));

app.use((req, res, next) => {
  if (
    req.path.match(
      /\.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$/
    )
  ) {
    res.setHeader(
      'Cache-Control',
      'public, max-age=31536000'
    );
  }

  next();
});

app.use(
  session({
    secret:
      process.env.SESSION_SECRET ||
      crypto.randomBytes(32).toString('hex'),

    store: new SQLiteStore({
      db: 'sessions.db',
      dir: './data'
    }),

    resave: false,

    saveUninitialized: false,

    cookie: {
      maxAge:
        7 * 24 * 60 * 60 * 1000
    }
  })
);

// CSRF protection MUST run after the session middleware.
app.use(csrfProtection);

// Make the CSRF token available to every EJS view.
app.use((req, res, next) => {
  try {
    if (typeof req.csrfToken === 'function') {
      res.locals.csrfToken =
        req.csrfToken();
    } else {
      res.locals.csrfToken =
        req.session &&
        req.session.csrfToken
          ? req.session.csrfToken
          : '';
    }
  } catch (error) {
    console.error(
      'CSRF token generation error:',
      error.message
    );

    res.locals.csrfToken = '';
  }

  next();
});

// Make logged-in user available to every view.
app.use((req, res, next) => {
  res.locals.user =
    req.session.user || null;

  const metadata = {
    '/': [
      'ApexMoto&Co | Motorcycle Lifestyle, Detailing & Servicing',
      'Apex Moto & Co. motorcycle lifestyle, detailing, store and basic motorcycle servicing.'
    ],

    '/about': [
      'About ApexMoto&Co',
      'Learn about Apex Moto & Co. and our motorcycle lifestyle, detailing and servicing offering.'
    ],

    '/contact': [
      'Contact ApexMoto&Co',
      'Contact Apex Moto & Co. for general, shop, events, detailing and motorcycle servicing enquiries.'
    ],

    '/store': [
      'ApexMoto&Co Store',
      'Shop Apex Moto & Co. products and complete secure checkout through Shopify.'
    ],

    '/detailing': [
      'Apex Moto Detailing',
      'Premium motorcycle detailing and vehicle care from Apex Moto & Co.'
    ],

    '/detailing/services': [
      'Basic Motorcycle Servicing',
      'Professional basic motorcycle servicing and routine motorcycle maintenance from Apex Moto Detailing.'
    ],

    '/detailing/booking': [
      'Book a Motorcycle Service or Detail',
      'Request a motorcycle detailing treatment or basic motorcycle servicing assessment.'
    ],

    '/services': [
      'Basic Motorcycle Servicing | ApexMoto&Co',
      'Professional basic motorcycle servicing and routine motorcycle maintenance from Apex Moto & Co.'
    ],

    '/events': [
      'ApexMoto&Co Events',
      'Find upcoming Apex Moto & Co. motorcycle events and community activities.'
    ]
  };

  const pageMetadata =
    metadata[req.path] ||
    [
      'ApexMoto&Co',
      'Apex Moto & Co. motorcycle lifestyle, detailing, store and servicing.'
    ];

  res.locals.pageTitle =
    pageMetadata[0];

  res.locals.metaDescription =
    pageMetadata[1];

  res.locals.canonicalUrl =
    `https://apexingoodcompany.co.uk${
      req.path === '/'
        ? '/'
        : req.path
    }`;

  res.locals.isPublicPage =
    !req.path.startsWith('/admin');

  next();
});

// Request logging
app.use(requestLogger);

// ============================================================
// VIEW ENGINE
// ============================================================

app.set(
  'view engine',
  'ejs'
);

app.set(
  'views',
  path.join(__dirname, 'views')
);

// ============================================================
// DATABASE INITIALISATION
// ============================================================

function initDB() {

  db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE,
      password TEXT,
      email TEXT,
      role TEXT DEFAULT 'user',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      totp_secret TEXT,
      totp_enabled INTEGER DEFAULT 0
    )
  `);

  db.run(
    `ALTER TABLE users ADD COLUMN last_login DATETIME`,
    (err) => {
      if (
        err &&
        !err.message.includes(
          'duplicate column name'
        )
      ) {
        console.error(
          'Unable to add users.last_login:',
          err.message
        );
      }
    }
  );

  db.run(
    `ALTER TABLE users ADD COLUMN display_name TEXT`,
    (err) => {
      if (
        err &&
        !err.message.includes(
          'duplicate column name'
        )
      ) {
        console.error(
          'Unable to add users.display_name:',
          err.message
        );
      }
    }
  );

  db.run(
    `ALTER TABLE users ADD COLUMN profile_picture TEXT`,
    (err) => {
      if (
        err &&
        !err.message.includes(
          'duplicate column name'
        )
      ) {
        console.error(
          'Unable to add users.profile_picture:',
          err.message
        );
      }
    }
  );

  db.run(
    `ALTER TABLE users ADD COLUMN is_active INTEGER DEFAULT 1`,
    (err) => {
      if (
        err &&
        !err.message.includes(
          'duplicate column name'
        )
      ) {
        console.error(
          'Unable to add users.is_active:',
          err.message
        );
      }
    }
  );

  db.run(
    `ALTER TABLE users ADD COLUMN last_activity DATETIME DEFAULT CURRENT_TIMESTAMP`,
    (err) => {
      if (
        err &&
        !err.message.includes(
          'duplicate column name'
        )
      ) {
        console.error(
          'Unable to add users.last_activity:',
          err.message
        );
      }
    }
  );

  db.run(`
    CREATE TABLE IF NOT EXISTS contact_messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT,
      email TEXT,
      department TEXT,
      subject TEXT,
      message TEXT,
      email_status TEXT DEFAULT 'pending',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  db.run(
    `ALTER TABLE contact_messages ADD COLUMN department TEXT`,
    (err) => {
      if (
        err &&
        !err.message.includes(
          'duplicate column name'
        )
      ) {
        console.error(
          'Unable to add contact_messages.department:',
          err.message
        );
      }
    }
  );

  db.run(
    `ALTER TABLE contact_messages ADD COLUMN email_status TEXT DEFAULT 'pending'`,
    (err) => {
      if (
        err &&
        !err.message.includes(
          'duplicate column name'
        )
      ) {
        console.error(
          'Unable to add contact_messages.email_status:',
          err.message
        );
      }
    }
  );

  db.run(`
    CREATE TABLE IF NOT EXISTS bookings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT,
      email TEXT,
      phone TEXT,
      vehicle_type TEXT,
      service_type TEXT,
      booking_date DATE,
      booking_time TIME,
      notes TEXT,
      status TEXT DEFAULT 'pending',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS announcements (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT,
      content TEXT,
      created_by INTEGER,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(created_by) REFERENCES users(id)
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS site_settings (
      id INTEGER PRIMARY KEY,
      site_name TEXT,
      site_tagline TEXT,
      hero_title TEXT,
      hero_subtitle TEXT,
      about_section_1 TEXT,
      about_section_2 TEXT,
      about_section_3 TEXT,
      footer_copyright TEXT,
      social_facebook TEXT,
      social_instagram TEXT,
      social_twitter TEXT,
      social_youtube TEXT,
      privacy_content TEXT,
      terms_content TEXT,
      cookies_content TEXT,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT,
      description TEXT,
      event_date DATE,
      event_time TIME,
      location TEXT,
      created_by INTEGER,
      status TEXT DEFAULT 'upcoming',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(created_by) REFERENCES users(id)
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS services (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      description TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS gallery_images (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      filename TEXT NOT NULL,
      original_name TEXT NOT NULL,
      title TEXT,
      alt_text TEXT NOT NULL,
      sort_order INTEGER DEFAULT 0,
      active INTEGER DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  const configuredAdmins = [
    [
      'adamgore',
      process.env.ADMIN_PASSWORD_1,
      process.env.ADMIN_EMAIL_1
    ],
    [
      'jordan',
      process.env.ADMIN_PASSWORD_2,
      process.env.ADMIN_EMAIL_2
    ]
  ];

  configuredAdmins.forEach(
    ([username, password, email]) => {

      if (!password || !email) {
        console.warn(
          `Admin seed skipped for ${username}: ADMIN_EMAIL and ADMIN_PASSWORD are required.`
        );

        return;
      }

      db.run(
        `INSERT OR IGNORE INTO users
         (username, password, email, role)
         VALUES (?, ?, ?, ?)`,
        [
          username,
          bcrypt.hashSync(
            password,
            10
          ),
          email,
          'admin'
        ]
      );
    }
  );
}

initDB();

// ============================================================
// AUTO BACKUP
// ============================================================

(function () {

  const fs = require('fs');

  const BACKUP_DIR =
    path.join(
      __dirname,
      'backups'
    );

  const DB_FILE =
    path.join(
      __dirname,
      'data',
      'database.db'
    );

  function backup() {

    try {

      if (!fs.existsSync(BACKUP_DIR)) {
        fs.mkdirSync(
          BACKUP_DIR,
          {
            recursive: true
          }
        );
      }

      const ts =
        new Date()
          .toISOString()
          .replace(
            /[:.]/g,
            '-'
          )
          .slice(0, -5);

      if (fs.existsSync(DB_FILE)) {

        fs.copyFileSync(
          DB_FILE,
          path.join(
            BACKUP_DIR,
            `database_${ts}.db`
          )
        );

      }

      const files =
        fs
          .readdirSync(
            BACKUP_DIR
          )
          .filter(
            file =>
              file.startsWith(
                'database_'
              )
          )
          .sort()
          .reverse();

      files
        .slice(30)
        .forEach(file => {
          fs.unlinkSync(
            path.join(
              BACKUP_DIR,
              file
            )
          );
        });

    } catch (e) {

      console.error(
        'Backup error:',
        e.message
      );

    }
  }

  backup();

  setInterval(
    backup,
    6 * 60 * 60 * 1000
  );

})();

// ============================================================
// AUTHENTICATION MIDDLEWARE
// ============================================================

function requireAdmin(
  req,
  res,
  next
) {

  if (
    !req.session.user ||
    req.session.user.role !== 'admin'
  ) {
    return res
      .status(403)
      .render(
        'error',
        {
          message:
            'Access Denied'
        }
      );
  }

  next();
}

function requireLogViewer(
  req,
  res,
  next
) {

  if (
    !req.session.user ||
    String(req.session.user.id) !== '3'
  ) {
    return res
      .status(403)
      .render(
        'error',
        {
          message:
            'Access Denied'
        }
      );
  }

  next();
}

function requireLogin(
  req,
  res,
  next
) {

  if (!req.session.user) {
    return res.redirect(
      '/login'
    );
  }

  next();
}

const workshopAuth = registerWorkshopAuth(
  app,
  db,
  {
    loginLimiter,
    secret: process.env.WORKSHOP_AUTH_SECRET
  }
);

registerDetailingMobileApi(
  app,
  db,
  {
    requireLogin,
    requireAdmin,
    workshopAuth
  }
);

// ============================================================
// PUBLIC ROUTES
// ============================================================

app.get(
  '/',
  (req, res) => {

    db.get(
      `SELECT * FROM site_settings
       WHERE id = 1`,
      (err, settings) => {

        res.render(
          'index',
          {
            settings:
              settings || {}
          }
        );

      }
    );

  }
);

app.get(
  '/about',
  (req, res) => {

    db.get(
      `SELECT * FROM site_settings
       WHERE id = 1`,
      (err, settings) => {

        res.render(
          'about',
          {
            settings:
              settings || {}
          }
        );

      }
    );

  }
);

// ============================================================
// LOGIN
// ============================================================

app.get(
  '/login',
  (req, res) => {
    res.render('login');
  }
);

app.post(
  '/login',
  loginLimiter,
  validateCSRF,
  (req, res) => {

    const {
      email,
      password
    } = req.body;

    if (!email || !password) {
      return res.render(
        'login',
        {
          error:
            'Invalid credentials'
        }
      );
    }

    db.get(
      `SELECT * FROM users
       WHERE username = ? OR email = ?`,
      [
        email,
        email
      ],
      async (
        err,
        user
      ) => {

        if (err) {

          console.error(
            'Login database error:',
            err
          );

          return res.render(
            'login',
            {
              error:
                'Unable to log in. Please try again.'
            }
          );

        }

        if (!user) {

          return res.render(
            'login',
            {
              error:
                'Invalid credentials'
            }
          );

        }

        try {

          const isBcryptHash =
            typeof user.password ===
              'string' &&
            /^\$2[aby]?\$\d{2}\$/.test(
              user.password
            );

          let valid = false;

          if (isBcryptHash) {

            valid =
              await bcrypt.compare(
                password,
                user.password
              );

          } else {

            valid =
              password ===
              user.password;

            if (valid) {

              const newHash =
                await bcrypt.hash(
                  password,
                  10
                );

              db.run(
                `UPDATE users
                 SET password = ?
                 WHERE id = ?`,
                [
                  newHash,
                  user.id
                ],
                updateErr => {

                  if (updateErr) {
                    console.error(
                      'Password upgrade error:',
                      updateErr
                    );
                  }

                }
              );

              user.password =
                newHash;

            }

          }

          if (!valid) {

            return res.render(
              'login',
              {
                error:
                  'Invalid credentials'
              }
            );

          }

          db.run(
            `UPDATE users
             SET last_login = CURRENT_TIMESTAMP
             WHERE id = ?`,
            [user.id],
            updateErr => {

              if (updateErr) {

                console.error(
                  'Last login update error:',
                  updateErr
                );

                return res.render(
                  'login',
                  {
                    error:
                      'Unable to complete login. Please try again.'
                  }
                );

              }

              user.last_login =
                new Date()
                  .toISOString();

              req.session.user =
                user;

              res.redirect(
                '/admin'
              );

            }
          );

        } catch (loginErr) {

          console.error(
            'Login error:',
            loginErr
          );

          res.render(
            'login',
            {
              error:
                'Unable to log in. Please try again.'
            }
          );

        }

      }
    );

  }
);

// ============================================================
// LOGOUT
// ============================================================

app.get(
  '/logout',
  (req, res) => {

    req.session.user = null;

    res.redirect('/');

  }
);

// ============================================================
// REGISTRATION
// ============================================================

app.get(
  '/register',
  (req, res) => {
    res.render(
      'register'
    );
  }
);

app.post(
  '/register',
  async (req, res) => {

    const {
      username,
      email,
      password
    } = req.body;

    if (
      !username ||
      !email ||
      !password
    ) {

      return res.render(
        'register',
        {
          error:
            'Please complete all fields.'
        }
      );

    }

    try {

      const hashedPassword =
        await bcrypt.hash(
          password,
          10
        );

      db.run(
        `
          INSERT INTO users
          (
            username,
            email,
            password,
            role
          )
          VALUES (?, ?, ?, ?)
        `,
        [
          username,
          email,
          hashedPassword,
          'user'
        ],
        err => {

          if (err) {

            console.error(
              'Registration error:',
              err
            );

            return res.render(
              'register',
              {
                error:
                  'Registration failed. Username or email may already exist.'
              }
            );

          }

          res.render(
            'register',
            {
              success:
                'Account created! Please log in.'
            }
          );

        }
      );

    } catch (err) {

      console.error(
        'Password hashing error:',
        err
      );

      res.render(
        'register',
        {
          error:
            'Registration failed. Please try again.'
        }
      );

    }

  }
);

// ============================================================
// ADMIN DASHBOARD
// ============================================================

app.get(
  '/admin',
  requireAdmin,
  (req, res) => {

    db.get(
      `SELECT COUNT(*) as bookings
       FROM bookings`,
      (err, bookings) => {

        db.get(
          `SELECT COUNT(*) as announcements
           FROM announcements`,
          (err, announcements) => {

            db.get(
              `SELECT COUNT(*) as items
               FROM store_items`,
              (err, items) => {

                db.get(
                  `SELECT COUNT(*) as users
                   FROM users`,
                  (err, users) => {

                    db.get(
                      `SELECT SUM(total_price) as orders
                       FROM orders
                       WHERE status = 'completed'`,
                      (err, orders) => {

                        const stats = {

                          bookings:
                            bookings
                              ? bookings.bookings
                              : 0,

                          announcements:
                            announcements
                              ? announcements.announcements
                              : 0,

                          items:
                            items
                              ? items.items
                              : 0,

                          users:
                            users
                              ? users.users
                              : 0,

                          orders:
                            orders &&
                            orders.orders
                              ? orders.orders
                              : 0

                        };

                        res.render(
                          'admin/dashboard',
                          {
                            stats
                          }
                        );

                      }
                    );

                  }
                );

              }
            );

          }
        );

      }
    );

  }
);

// ============================================================
// ADMIN SETTINGS
// ============================================================

app.get(
  '/admin/settings',
  requireAdmin,
  (req, res) => {

    db.get(
      `SELECT * FROM site_settings
       WHERE id = 1`,
      (err, settings) => {

        res.render(
          'admin/settings',
          {
            settings:
              settings || {}
          }
        );

      }
    );

  }
);

app.post(
  '/admin/settings',
  requireAdmin,
  (req, res) => {

    const {
      site_name,
      site_tagline,
      hero_title,
      hero_subtitle,
      about_section_1,
      about_section_2,
      about_section_3,
      footer_copyright,
      social_facebook,
      social_instagram,
      social_twitter,
      social_youtube,
      privacy_content,
      terms_content,
      cookies_content
    } = req.body;

    db.run(
      `
        INSERT OR REPLACE INTO site_settings
        (
          id,
          site_name,
          site_tagline,
          hero_title,
          hero_subtitle,
          about_section_1,
          about_section_2,
          about_section_3,
          footer_copyright,
          social_facebook,
          social_instagram,
          social_twitter,
          social_youtube,
          privacy_content,
          terms_content,
          cookies_content
        )
        VALUES
        (
          1, ?, ?, ?, ?, ?, ?, ?, ?,
          ?, ?, ?, ?, ?, ?, ?
        )
      `,
      [
        site_name,
        site_tagline,
        hero_title,
        hero_subtitle,
        about_section_1,
        about_section_2,
        about_section_3,
        footer_copyright,
        social_facebook,
        social_instagram,
        social_twitter,
        social_youtube,
        privacy_content,
        terms_content,
        cookies_content
      ],
      err => {

        if (err) {
          return res
            .status(500)
            .send(
              'Error saving settings'
            );
        }

        res.json({
          success: true
        });

      }
    );

  }
);

// ============================================================
// STORE
// ============================================================



app.get(
  '/admin/store',
  requireAdmin,
  (req, res) => {
    res.render(
      'admin/store',
      {
        items: []
      }
    );
  }
);

// ============================================================
// DETAILING
// ============================================================

app.get(
  '/detailing',
  (req, res) => {
    res.render(
      'detailing'
    );
  }
);

app.get(
  '/detailing/booking',
  (req, res) => {
    res.render(
      'detailing/booking'
    );
  }
);

app.get(
  '/detailing/memberships',
  (req, res) => {
    res.render(
      'detailing/memberships'
    );
  }
);

app.get(
  '/detailing/portfolio',
  (req, res) => {

    db.all(
      'SELECT * FROM gallery_images WHERE active = 1 ORDER BY sort_order ASC, id DESC',
      (err, images) => {

        if (err) {

          console.error(
            'Unable to load gallery images:',
            err.message
          );

          return res
            .status(500)
            .render(
              'error',
              {
                message:
                  'Unable to load the portfolio gallery.'
              }
            );

        }

        res.render(
          'detailing/portfolio',
          {
            images:
              images || []
          }
        );

      }
    );

  }
);

app.get(
  '/uploads/gallery/:filename',
  (req, res) => {

    const filename =
      path.basename(
        req.params.filename
      );

    const filePath =
      path.join(
        galleryDirectory,
        filename
      );

    if (!fs.existsSync(filePath)) {
      return res
        .status(404)
        .send(
          'Image not found'
        );
    }

    res.sendFile(
      filePath
    );

  }
);// ============================================================
// ADMIN GALLERY
// ============================================================

app.get(
  '/admin/gallery',
  requireAdmin,
  (req, res) => {

    db.all(
      'SELECT * FROM gallery_images ORDER BY sort_order ASC, id DESC',
      (err, images) => {

        if (err) {

          console.error(
            'Unable to load admin gallery:',
            err.message
          );

          return res
            .status(500)
            .render(
              'error',
              {
                message:
                  'Unable to load the gallery manager.'
              }
            );

        }

        res.render(
          'admin/gallery',
          {
            images:
              images || []
          }
        );

      }
    );

  }
);

app.post(
  '/admin/gallery',
  requireAdmin,
  galleryUpload.single('image'),
  validateCSRF,
  (req, res) => {

    if (!req.file) {

      return res
        .status(400)
        .render(
          'error',
          {
            message:
              'Please select a valid image to upload.'
          }
        );

    }

    const title =
      String(
        req.body.title || ''
      ).trim();

    const altText =
      String(
        req.body.alt_text ||
        title ||
        'Apex Moto Detailing portfolio image'
      ).trim();

    const sortOrder =
      Number.isInteger(
        Number(req.body.sort_order)
      )
        ? Number(req.body.sort_order)
        : 0;

    db.run(
      `
        INSERT INTO gallery_images
        (
          filename,
          original_name,
          title,
          alt_text,
          sort_order
        )
        VALUES (?, ?, ?, ?, ?)
      `,
      [
        req.file.filename,
        req.file.originalname,
        title,
        altText,
        sortOrder
      ],
      err => {

        if (err) {

          fs.unlink(
            req.file.path,
            () => {}
          );

          console.error(
            'Unable to save gallery image:',
            err.message
          );

          return res
            .status(500)
            .render(
              'error',
              {
                message:
                  'Unable to save the gallery image.'
              }
            );

        }

        res.redirect(
          '/admin/gallery'
        );

      }
    );

  }
);

app.post(
  '/admin/gallery/:id/delete',
  requireAdmin,
  validateCSRF,
  (req, res) => {

    db.get(
      'SELECT filename FROM gallery_images WHERE id = ?',
      [req.params.id],
      (findErr, image) => {

        if (
          findErr ||
          !image
        ) {

          return res
            .status(404)
            .render(
              'error',
              {
                message:
                  'Gallery image not found.'
              }
            );

        }

        db.run(
          'DELETE FROM gallery_images WHERE id = ?',
          [req.params.id],
          deleteErr => {

            if (deleteErr) {

              return res
                .status(500)
                .render(
                  'error',
                  {
                    message:
                      'Unable to delete the gallery image.'
                  }
                );

            }

            fs.unlink(
              path.join(
                galleryDirectory,
                path.basename(
                  image.filename
                )
              ),
              unlinkErr => {

                if (
                  unlinkErr &&
                  unlinkErr.code !==
                    'ENOENT'
                ) {

                  console.error(
                    'Unable to delete gallery file:',
                    unlinkErr.message
                  );

                }

                res.redirect(
                  '/admin/gallery'
                );

              }
            );

          }
        );

      }
    );

  }
);

// ============================================================
// DETAILING SERVICES
// ============================================================

app.get(
  '/detailing/services',
  (req, res) => {

    res.redirect(
      301,
      '/services'
    );

  }
);

// ============================================================
// DETAILING BOOKING
// ============================================================
//
// IMPORTANT:
// This is the corrected booking route.
//
// The previous version incorrectly used:
//
//   service_type || treatment
//
// as though it were a database column.
//
// The bookings table contains:
//
//   service_type
//
// and the booking form already submits the selected
// treatment/package through service_type.
//
// ============================================================

app.post(
  '/detailing/book',
  (req, res) => {

    const {
      name,
      email,
      phone,
      vehicle_type,
      service_type,
      booking_date,
      booking_time,
      notes
    } = req.body || {};

    // --------------------------------------------------------
    // Validate required fields
    // --------------------------------------------------------

    if (
      !name ||
      !email ||
      !phone ||
      !vehicle_type ||
      !service_type
    ) {

      return res
        .status(400)
        .json(
          {
            error:
              'Please complete all required booking details.'
          }
        );

    }

    // --------------------------------------------------------
    // Insert booking
    // --------------------------------------------------------

    db.run(
      `
        INSERT INTO bookings
        (
          name,
          email,
          phone,
          vehicle_type,
          service_type,
          booking_date,
          booking_time,
          notes,
          status
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `,
      [
        String(name).trim(),
        String(email).trim(),
        String(phone).trim(),
        String(vehicle_type).trim(),
        String(service_type).trim(),
        booking_date || null,
        booking_time || null,
        notes
          ? String(notes).trim()
          : '',
        'pending'
      ],
      function (err) {

        if (err) {

          console.error(
            '[DETAILING BOOKING] Database insert failed:',
            err.message
          );

          return res
            .status(500)
            .json(
              {
                error:
                  'Booking failed'
              }
            );

        }

        console.log(
          `[DETAILING BOOKING] Booking created: ${this.lastID}`
        );

        return res
          .status(201)
          .json(
            {
              success: true,
              booking_id:
                this.lastID,
              message:
                'Booking confirmed!'
            }
          );

      }
    );

  }
);

// ============================================================
// ADMIN DETAILING BOOKINGS
// ============================================================

app.get(
  '/admin/detailing/bookings',
  requireAdmin,
  (req, res) => {

    db.all(
      `
        SELECT *
        FROM bookings
        ORDER BY booking_date DESC
      `,
      (err, bookings) => {

        if (err) {

          console.error(
            'Unable to load detailing bookings:',
            err.message
          );

          return res
            .status(500)
            .render(
              'error',
              {
                message:
                  'Unable to load detailing bookings.'
              }
            );

        }

        res.render(
          'admin/detailing-bookings',
          {
            bookings:
              bookings || []
          }
        );

      }
    );

  }
);

// ============================================================
// CONTACT
// ============================================================

app.get(
  '/contact',
  (req, res) => {

    res.render(
      'contact'
    );

  }
);

app.get(
  '/admin/contact-messages',
  requireAdmin,
  (req, res) => {

    db.all(
      `
        SELECT
          id,
          name,
          email,
          department,
          subject,
          message,
          email_status,
          created_at
        FROM contact_messages
        ORDER BY created_at DESC
        LIMIT 250
      `,
      (err, messages) => {

        if (err) {

          console.error(
            'Contact message lookup failed:',
            err.message
          );

          return res
            .status(500)
            .render(
              'error',
              {
                message:
                  'Unable to load contact messages.'
              }
            );

        }

        res.render(
          'admin/contact-messages',
          {
            messages:
              messages || []
          }
        );

      }
    );

  }
);

app.post(
  '/contact',
  contactFormLimiter,
  validateCSRF,
  async (req, res) => {

    const {
      name,
      email,
      department,
      subject,
      message,
      website
    } = req.body;

    const emailPattern =
      /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (
      website ||
      !name ||
      !emailPattern.test(
        email || ''
      ) ||
      !department ||
      !subject ||
      !message
    ) {

      return res
        .status(400)
        .render(
          'contact',
          {
            error:
              'Please complete the form with a valid email address.'
          }
        );

    }

    const {
      sendContactEmail
    } = require(
      './services/email'
    );

    db.run(
      `
        INSERT INTO contact_messages
        (
          name,
          email,
          department,
          subject,
          message,
          email_status
        )
        VALUES (?, ?, ?, ?, ?, ?)
      `,
      [
        name,
        email,
        department,
        subject,
        message,
        'pending'
      ],
      async function (err) {

        if (err) {

          return res
            .status(500)
            .send(
              'Error saving message'
            );

        }

        try {

          const sent =
            await sendContactEmail(
              name,
              email,
              department,
              subject,
              message
            );

          db.run(
            `
              UPDATE contact_messages
              SET email_status = ?
              WHERE id = ?
            `,
            [
              sent
                ? 'sent'
                : 'failed',
              this.lastID
            ]
          );

          if (sent) {

            const {
              sendContactConfirmation
            } = require(
              './services/email'
            );

            await sendContactConfirmation(
              email,
              name,
              subject
            );

          }

        } catch (emailError) {

          console.error(
            'Contact email error:',
            emailError
          );

        }

        res.render(
          'contact',
          {
            success:
              'Message sent successfully! We will contact you soon.'
          }
        );

      }
    );

  }
);

// ============================================================
// SERVICES
// ============================================================

app.get(
  '/services',
  (req, res) => {

    res.render(
      'detailing/services'
    );

  }
);

// ============================================================
// ADMIN SERVICES
// ============================================================

app.get(
  '/admin/services',
  requireAdmin,
  (req, res) => {

    db.all(
      'SELECT * FROM services ORDER BY id',
      (err, services) => {

        res.render(
          'admin/services',
          {
            services:
              services || []
          }
        );

      }
    );

  }
);

app.post(
  '/admin/services',
  requireAdmin,
  (req, res) => {

    const {
      name,
      description
    } = req.body;

    db.run(
      `
        INSERT INTO services
        (
          name,
          description
        )
        VALUES (?, ?)
      `,
      [
        name,
        description
      ],
      err => {

        if (err) {

          return res
            .status(500)
            .json(
              {
                error:
                  'Error adding service'
              }
            );

        }

        res.json(
          {
            success: true
          }
        );

      }
    );

  }
);

app.put(
  '/admin/services/:id',
  requireAdmin,
  (req, res) => {

    const {
      name,
      description
    } = req.body;

    db.run(
      `
        UPDATE services
        SET
          name = ?,
          description = ?
        WHERE id = ?
      `,
      [
        name,
        description,
        req.params.id
      ],
      err => {

        if (err) {

          return res
            .status(500)
            .json(
              {
                error:
                  'Error updating service'
              }
            );

        }

        res.json(
          {
            success: true
          }
        );

      }
    );

  }
);

app.delete(
  '/admin/services/:id',
  requireAdmin,
  (req, res) => {

    db.run(
      `
        DELETE FROM services
        WHERE id = ?
      `,
      [
        req.params.id
      ],
      err => {

        if (err) {

          return res
            .status(500)
            .json(
              {
                error:
                  'Error deleting service'
              }
            );

        }

        res.json(
          {
            success: true
          }
        );

      }
    );

  }
);

// ============================================================
// EVENTS
// ============================================================

app.get(
  '/events',
  (req, res) => {

    db.all(
      `
        SELECT *
        FROM events
        WHERE status IN
        (
          'upcoming',
          'ongoing'
        )
        ORDER BY event_date ASC
      `,
      (err, events) => {

        if (err) {

          console.error(
            'Error fetching events:',
            err
          );

        }

        res.render(
          'events',
          {
            events:
              events || []
          }
        );

      }
    );

  }
);

app.get(
  '/admin/events',
  requireAdmin,
  (req, res) => {

    db.all(
      `
        SELECT *
        FROM events
        ORDER BY event_date DESC
      `,
      (err, events) => {

        res.render(
          'admin/events',
          {
            events:
              events || []
          }
        );

      }
    );

  }
);

app.post(
  '/admin/events',
  requireAdmin,
  (req, res) => {

    const {
      title,
      description,
      event_date,
      event_time,
      location
    } = req.body;

    db.run(
      `
        INSERT INTO events
        (
          title,
          description,
          event_date,
          event_time,
          location,
          created_by,
          status
        )
        VALUES
        (?, ?, ?, ?, ?, ?, 'upcoming')
      `,
      [
        title,
        description,
        event_date,
        event_time,
        location,
        req.session.user.id
      ],
      err => {

        if (err) {

          return res
            .status(500)
            .json(
              {
                error:
                  err.message
              }
            );

        }

        res.json(
          {
            success: true
          }
        );

      }
    );

  }
);

// ============================================================
// ANNOUNCEMENTS
// ============================================================

app.get(
  '/announcements',
  (req, res) => {

    db.all(
      `
        SELECT *
        FROM announcements
        ORDER BY created_at DESC
      `,
      (err, announcements) => {

        res.render(
          'announcements',
          {
            announcements:
              announcements || []
          }
        );

      }
    );

  }
);

app.get(
  '/admin/announcements',
  requireAdmin,
  (req, res) => {

    db.all(
      `
        SELECT *
        FROM announcements
        ORDER BY created_at DESC
      `,
      (err, announcements) => {

        res.render(
          'admin/announcements',
          {
            announcements:
              announcements || []
          }
        );

      }
    );

  }
);

app.post(
  '/admin/announcements',
  requireAdmin,
  (req, res) => {

    const {
      title,
      content
    } = req.body;

    db.run(
      `
        INSERT INTO announcements
        (
          title,
          content,
          created_by
        )
        VALUES (?, ?, ?)
      `,
      [
        title,
        content,
        req.session.user.id
      ],
      err => {

        if (err) {

          return res
            .status(500)
            .json(
              {
                error:
                  'Error creating announcement'
              }
            );

        }

        res.json(
          {
            success: true
          }
        );

      }
    );

  }
);

// ============================================================
// USERS
// ============================================================

app.get(
  '/admin/users',
  requireAdmin,
  (req, res) => {

    db.all(
      `SELECT * FROM users`,
      (err, users) => {

        res.render(
          'admin/users',
          {
            users:
              users || []
          }
        );

      }
    );

  }
);

app.post(
  '/admin/users',
  requireAdmin,
  async (req, res) => {

    const {
      username,
      password,
      email,
      role
    } = req.body;

    try {

      const hashedPassword =
        await bcrypt.hash(
          password,
          10
        );

      db.run(
        `
          INSERT INTO users
          (
            username,
            password,
            email,
            role
          )
          VALUES (?, ?, ?, ?)
        `,
        [
          username,
          hashedPassword,
          email,
          role
        ],
        err => {

          if (err) {

            return res
              .status(500)
              .json(
                {
                  error:
                    'Error creating user'
                }
              );

          }

          res.json(
            {
              success: true
            }
          );

        }
      );

    } catch (err) {

      console.error(
        'Admin user password hashing error:',
        err
      );

      res
        .status(500)
        .json(
          {
            error:
              'Error creating user'
          }
        );

    }

  }
);// ============================================================
// DELETE USER
// ============================================================

app.delete(
  '/admin/users/:id',
  requireAdmin,
  (req, res) => {

    const userId =
      Number(req.params.id);

    if (!Number.isInteger(userId)) {

      return res
        .status(400)
        .json({
          error:
            'Invalid user ID'
        });

    }

    if (
      req.session.user.id ===
      userId
    ) {

      return res
        .status(400)
        .json({
          error:
            'You cannot delete your own admin account.'
        });

    }

    db.run(
      `
        DELETE FROM users
        WHERE id = ?
      `,
      [userId],
      function (err) {

        if (err) {

          console.error(
            'Error deleting user:',
            err
          );

          return res
            .status(500)
            .json({
              error:
                'Error deleting user'
            });

        }

        if (this.changes === 0) {

          return res
            .status(404)
            .json({
              error:
                'User not found'
            });

        }

        res.json({
          success: true
        });

      }
    );

  }
);

// ============================================================
// UPDATE USER ROLE
// ============================================================

app.put(
  '/admin/users/:id/role',
  requireAdmin,
  (req, res) => {

    const userId =
      Number(req.params.id);

    const {
      role
    } = req.body;

    if (!Number.isInteger(userId)) {

      return res
        .status(400)
        .json({
          error:
            'Invalid user ID'
        });

    }

    if (
      ![
        'user',
        'admin'
      ].includes(role)
    ) {

      return res
        .status(400)
        .json({
          error:
            'Invalid role. Use "user" or "admin".'
        });

    }

    if (
      userId ===
        req.session.user.id &&
      role !== 'admin'
    ) {

      return res
        .status(400)
        .json({
          error:
            'You cannot remove your own admin access.'
        });

    }

    db.run(
      `
        UPDATE users
        SET role = ?
        WHERE id = ?
      `,
      [
        role,
        userId
      ],
      function (err) {

        if (err) {

          console.error(
            'Error updating user role:',
            err
          );

          return res
            .status(500)
            .json({
              error:
                'Error updating user role'
            });

        }

        if (this.changes === 0) {

          return res
            .status(404)
            .json({
              error:
                'User not found'
            });

        }

        if (
          userId ===
          req.session.user.id
        ) {

          req.session.user.role =
            role;

        }

        res.json({
          success: true,
          message:
            `User role changed to ${role}`
        });

      }
    );

  }
);

// ============================================================
// UPDATE USER PASSWORD
// ============================================================

app.put(
  '/admin/users/:id/password',
  requireAdmin,
  async (req, res) => {

    const userId =
      Number(req.params.id);

    const {
      password
    } = req.body;

    if (!Number.isInteger(userId)) {

      return res
        .status(400)
        .json({
          error:
            'Invalid user ID'
        });

    }

    if (
      typeof password !==
        'string' ||
      password.length < 8
    ) {

      return res
        .status(400)
        .json({
          error:
            'Password must be at least 8 characters'
        });

    }

    try {

      const hashedPassword =
        await bcrypt.hash(
          password,
          10
        );

      db.run(
        `
          UPDATE users
          SET password = ?
          WHERE id = ?
        `,
        [
          hashedPassword,
          userId
        ],
        function (err) {

          if (err) {

            console.error(
              'Error updating password:',
              err
            );

            return res
              .status(500)
              .json({
                error:
                  'Error updating password'
              });

          }

          if (
            this.changes === 0
          ) {

            return res
              .status(404)
              .json({
                error:
                  'User not found'
              });

          }

          res.json({
            success: true,
            message:
              'Password updated successfully'
          });

        }
      );

    } catch (err) {

      console.error(
        'Password hashing error:',
        err
      );

      res
        .status(500)
        .json({
          error:
            'Error updating password'
        });

    }

  }
);

// ============================================================
// COMPETITIONS
// ============================================================

// Competitions Management - Empty for now

app.get(
  '/admin/competitions',
  requireAdmin,
  (req, res) => {

    res.render(
      'admin/competitions',
      {
        competitions: []
      }
    );

  }
);

// Live competitions

app.get(
  '/competitions/live',
  (req, res) => {

    res.render(
      'live-competitions',
      {
        competitions: []
      }
    );

  }
);

// Past competitions

app.get(
  '/competitions/past',
  (req, res) => {

    res.render(
      'past-competitions',
      {
        competitions: []
      }
    );

  }
);

// Winners

app.get(
  '/winners',
  (req, res) => {

    res.render(
      'winners',
      {
        winners: []
      }
    );

  }
);

// ============================================================
// COMPETITION ENTRY
// ============================================================

app.get(
  '/competitions/:id/entry',
  requireLogin,
  (req, res) => {

    res
      .status(404)
      .render(
        'error',
        {
          message:
            'Competition not found'
        }
      );

  }
);

app.post(
  '/competitions/:id/entry',
  requireLogin,
  (req, res) => {

    res
      .status(404)
      .json({
        error:
          'Competition not found'
      });

  }
);

// ============================================================
// REMOVED COMPETITION PAGES
// ============================================================

app.get(
  '/competitions/*',
  (req, res) => {

    res
      .status(410)
      .render(
        'error',
        {
          message:
            'Competitions have been removed from this site.'
        }
      );

  }
);

// ============================================================
// SALES DASHBOARD
// ============================================================

app.get(
  '/admin/sales',
  requireAdmin,
  (req, res) => {

    db.all(
      `
        SELECT
          service_type,
          COUNT(*) AS count,
          SUM(
            CASE
              WHEN status = 'confirmed'
              THEN 1
              ELSE 0
            END
          ) AS confirmed
        FROM bookings
        GROUP BY service_type
        ORDER BY count DESC
      `,
      (err, bookingStats) => {

        db.all(
          `
            SELECT
              strftime(
                '%Y-%m',
                booking_date
              ) AS month,
              COUNT(*) AS count
            FROM bookings
            WHERE booking_date IS NOT NULL
            GROUP BY month
            ORDER BY month DESC
            LIMIT 12
          `,
          (err, monthlyTrend) => {

            db.get(
              `
                SELECT COUNT(*) AS total
                FROM bookings
              `,
              (err, totalRow) => {

                db.get(
                  `
                    SELECT COUNT(*) AS confirmed
                    FROM bookings
                    WHERE status = 'confirmed'
                  `,
                  (err, confirmedRow) => {

                    const totalBookings =
                      totalRow
                        ? totalRow.total
                        : 0;

                    const confirmedBookings =
                      confirmedRow
                        ? confirmedRow.confirmed
                        : 0;

                    const totalRevenue =
                      totalBookings *
                      50;

                    const shopify =
                      require(
                        './services/shopify'
                      );

                    shopify
                      .getOrders()
                      .then(
                        shopifyOrders => {

                          const datePattern =
                            /^\d{4}-\d{2}-\d{2}$/;

                          const fromDate =
                            datePattern.test(
                              req.query.from ||
                              ''
                            )
                              ? req.query.from
                              : '';

                          const toDate =
                            datePattern.test(
                              req.query.to ||
                              ''
                            )
                              ? req.query.to
                              : '';

                          const filteredShopifyOrders =
                            shopifyOrders.filter(
                              order => {

                                const createdDate =
                                  String(
                                    order.created_at ||
                                    ''
                                  ).slice(
                                    0,
                                    10
                                  );

                                return (
                                  (
                                    !fromDate ||
                                    createdDate >=
                                      fromDate
                                  ) &&
                                  (
                                    !toDate ||
                                    createdDate <=
                                      toDate
                                  )
                                );

                              }
                            );

                          const storeRevenue =
                            filteredShopifyOrders.reduce(
                              (
                                total,
                                order
                              ) => {

                                const amount =
                                  Number(
                                    order.current_total_price ||
                                    order.total_price ||
                                    0
                                  );

                                return (
                                  total +
                                  (
                                    Number.isFinite(
                                      amount
                                    )
                                      ? amount
                                      : 0
                                  )
                                );

                              },
                              0
                            );

                          const productSales =
                            {};

                          filteredShopifyOrders.forEach(
                            order => {

                              (
                                order.line_items ||
                                []
                              ).forEach(
                                item => {

                                  const key =
                                    item.title ||
                                    'Unknown product';

                                  if (
                                    !productSales[
                                      key
                                    ]
                                  ) {

                                    productSales[
                                      key
                                    ] = {
                                      title:
                                        key,
                                      quantity:
                                        0,
                                      revenue:
                                        0
                                    };

                                  }

                                  productSales[
                                    key
                                  ].quantity +=
                                    Number(
                                      item.quantity
                                    ) || 0;

                                  productSales[
                                    key
                                  ].revenue +=
                                    (
                                      Number(
                                        item.price
                                      ) || 0
                                    ) *
                                    (
                                      Number(
                                        item.quantity
                                      ) || 0
                                    );

                                }
                              );

                            }
                          );

                          const stats = {

                            error:
                              null,

                            totalBookings,

                            confirmedBookings,

                            totalRevenue,

                            storeRevenue,

                            shopifyOrderCount:
                              filteredShopifyOrders.length,

                            shopifyConnected:
                              true,

                            shopifyLastSync:
                              new Date(),

                            shopifyFrom:
                              fromDate,

                            shopifyTo:
                              toDate,

                            recentShopifyOrders:
                              filteredShopifyOrders.slice(
                                0,
                                10
                              ),

                            shopifyProductSales:
                              Object.values(
                                productSales
                              ).sort(
                                (
                                  a,
                                  b
                                ) =>
                                  b.revenue -
                                  a.revenue
                              ),

                            bookingStats:
                              bookingStats ||
                              [],

                            monthlyTrend:
                              (
                                monthlyTrend ||
                                []
                              ).reverse(),

                            recentBookings:
                              []

                          };

                          res.render(
                            'admin/sales',
                            stats
                          );

                        }
                      )
                      .catch(
                        error => {

                          console.error(
                            'Shopify sales dashboard error:',
                            error.response?.data ||
                            error.message
                          );

                          res.render(
                            'admin/sales',
                            {

                              error:
                                'Shopify sales data is unavailable. Check the Shopify Admin API credentials.',

                              totalBookings,

                              confirmedBookings,

                              totalRevenue,

                              storeRevenue:
                                null,

                              shopifyOrderCount:
                                null,

                              shopifyConnected:
                                false,

                              shopifyLastSync:
                                null,

                              shopifyFrom:
                                req.query.from ||
                                '',

                              shopifyTo:
                                req.query.to ||
                                '',

                              recentShopifyOrders:
                                [],

                              shopifyProductSales:
                                [],

                              bookingStats:
                                bookingStats ||
                                [],

                              monthlyTrend:
                                (
                                  monthlyTrend ||
                                  []
                                ).reverse(),

                              recentBookings:
                                []

                            }
                          );

                        }
                      );

                  }
                );

              }
            );

          }
        );

      }
    );

  }
);

// ============================================================
// BOOKING CSV EXPORT
// ============================================================

app.get(
  '/admin/detailing/bookings/export',
  requireAdmin,
  (req, res) => {

    db.all(
      `
        SELECT *
        FROM bookings
        ORDER BY booking_date DESC
      `,
      (err, bookings) => {

        if (err) {

          return res
            .status(500)
            .json({
              error:
                'Export failed'
            });

        }

        let csv =
          'ID,Name,Email,Phone,Vehicle,Service,Date,Time,Status,Created\n';

        (
          bookings || []
        ).forEach(
          booking => {

            const escaped =
              value =>
                value
                  ? String(
                      value
                    ).replace(
                      /"/g,
                      '""'
                    )
                  : '';

            csv +=
              booking.id +
              ',"' +
              escaped(
                booking.name
              ) +
              '","' +
              escaped(
                booking.email
              ) +
              '","' +
              escaped(
                booking.phone
              ) +
              '","' +
              escaped(
                booking.vehicle_type
              ) +
              '","' +
              escaped(
                booking.service_type
              ) +
              '",' +
              (
                booking.booking_date ||
                ''
              ) +
              ',' +
              (
                booking.booking_time ||
                ''
              ) +
              ',' +
              (
                booking.status ||
                ''
              ) +
              ',' +
              (
                booking.created_at ||
                ''
              ) +
              '\n';

          }
        );

        res.setHeader(
          'Content-Type',
          'text/csv; charset=utf-8'
        );

        res.setHeader(
          'Content-Disposition',
          'attachment; filename=bookings.csv'
        );

        res.send(
          csv
        );

      }
    );

  }
);

// ============================================================
// AUDIT LOGS
// ============================================================

app.get(
  '/admin/audit-logs',
  requireLogViewer,
  async (req, res) => {

    try {

      const {
        getAuditLogs
      } = require(
        './services/audit'
      );

      const logs =
        await getAuditLogs(
          500
        );

      res.render(
        'admin/audit-logs',
        {
          logs
        }
      );

    } catch (error) {

      console.error(
        'Error loading audit logs:',
        error
      );

      res
        .status(500)
        .render(
          'error',
          {
            message:
              'Unable to load audit logs.'
          }
        );

    }

  }
);

// ============================================================
// LEGAL PAGES
// ============================================================

app.get(
  '/privacy',
  (req, res) => {

    db.get(
      `
        SELECT *
        FROM site_settings
        WHERE id = 1
      `,
      (err, settings) => {

        res.render(
          'privacy',
          {
            settings:
              settings || {}
          }
        );

      }
    );

  }
);

app.get(
  '/terms',
  (req, res) => {

    db.get(
      `
        SELECT *
        FROM site_settings
        WHERE id = 1
      `,
      (err, settings) => {

        res.render(
          'terms',
          {
            settings:
              settings || {}
          }
        );

      }
    );

  }
);

app.get(
  '/cookies',
  (req, res) => {

    db.get(
      `
        SELECT *
        FROM site_settings
        WHERE id = 1
      `,
      (err, settings) => {

        res.render(
          'cookies',
          {
            settings:
              settings || {}
          }
        );

      }
    );

  }
);

// ============================================================
// HEALTH CHECK
// ============================================================

app.get(
  '/health',
  (req, res) => {

    res.json({
      status:
        'OK',

      timestamp:
        new Date().toISOString(),

      uptime:
        process.uptime()
    });

  }
);

app.get(
  '/admin/health',
  requireAdmin,
  async (req, res) => {

    const fs =
      require('fs');

    const shopify =
      require(
        './services/shopify'
      );

    const {
      transporter
    } = require(
      './services/email'
    );

    const checks = {

      application: {
        status:
          'ok',

        detail:
          'Application process is running.'
      },

      database: {
        status:
          'unknown',

        detail:
          'Checking database.'
      },

      shopify: {
        status:
          'unknown',

        detail:
          'Checking Shopify Admin API.'
      },

      smtp: {
        status:
          'unknown',

        detail:
          'Checking SMTP configuration.'
      },

      backups: {
        status:
          'unknown',

        detail:
          'Checking backup directory.'
      }

    };

    await new Promise(
      resolve => {

        db.get(
          'SELECT 1 AS ok',
          (err, row) => {

            checks.database =
              err
                ? {
                    status:
                      'error',

                    detail:
                      err.message
                  }
                : {
                    status:
                      'ok',

                    detail:
                      row &&
                      row.ok === 1
                        ? 'SQLite query succeeded.'
                        : 'Unexpected database response.'
                  };

            resolve();

          }
        );

      }
    );

    try {

      await shopify.getOrders();

      checks.shopify = {
        status:
          'ok',

        detail:
          'Shopify orders endpoint responded.'
      };

    } catch (error) {

      checks.shopify = {
        status:
          'error',

        detail:
          'Shopify Admin API credentials or access are unavailable.'
      };

    }

    try {

      await transporter.verify();

      checks.smtp = {
        status:
          'ok',

        detail:
          'SMTP connection verified.'
      };

    } catch (error) {

      checks.smtp = {
        status:
          'error',

        detail:
          'SMTP connection could not be verified.'
      };

    }

    try {

      const backupDir =
        path.join(
          __dirname,
          'backups'
        );

      const files =
        fs.existsSync(
          backupDir
        )
          ? fs
              .readdirSync(
                backupDir
              )
              .filter(
                file =>
                  file.endsWith(
                    '.db'
                  )
              )
          : [];

      checks.backups = {

        status:
          files.length
            ? 'ok'
            : 'warning',

        detail:
          files.length
            ? `${files.length} database backup file(s) found.`
            : 'No database backups found.'

      };

    } catch (error) {

      checks.backups = {
        status:
          'error',

        detail:
          'Backup directory could not be read.'
      };

    }

    res.render(
      'admin/health',
      {
        checks,
        checkedAt:
          new Date()
      }
    );

  }
);

// ============================================================
// ACTIVITY LOGS DASHBOARD
// ============================================================

app.get(
  '/admin/activity-logs',
  requireLogViewer,
  async (req, res) => {

    try {

      const {
        getAuditLogs
      } = require(
        './services/audit'
      );

      const logs =
        await getAuditLogs(
          500
        );

      res.render(
        'admin/activity-logs-dashboard',
        {
          logs:
            logs || []
        }
      );

    } catch (error) {

      console.error(
        'Error loading activity logs:',
        error
      );

      res
        .status(500)
        .render(
          'error',
          {
            message:
              'Unable to load activity logs.'
          }
        );

    }

  }
);// ============================================================
// 2FA VERIFICATION ROUTE
// ============================================================

// ============================================================
// 2FA VERIFICATION ROUTE
// ============================================================

app.get('/admin/2fa-verify', (req, res) => {
  if (!req.session.user) {
    return res.redirect('/login');
  }
  res.render('admin/2fa-verify');
});

app.get('/admin/enable-2fa', async (req, res) => {
  if (!req.session.user) {
    return res.redirect('/login');
  }
  const { generateTOTPSecret } = require('./services/2fa');
  const QRCode = require('qrcode');
  
  try {
    const secret = generateTOTPSecret();
    req.session.temp2FASecret = secret;
    
    const otpauthURL = `otpauth://totp/ApexMoto&Co:${req.session.user.email}?secret=${secret}&issuer=ApexMoto&Co`;
    const qrCode = await QRCode.toDataURL(otpauthURL);
    
    res.render('admin/enable-2fa', { qrCode, secret });
  } catch (error) {
    console.error('2FA page error:', error);
    res.render('admin/enable-2fa', { qrCode: null, secret: 'ERROR' });
  }
});

app.get('/admin/generate-2fa-qr', async (req, res) => {
  if (!req.session.user || !req.session.temp2FASecret) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  const { generateQRCode } = require('./services/2fa');
  try {
    const otpauthURL = `otpauth://totp/ApexMoto&Co:${req.session.user.email}?secret=${req.session.temp2FASecret}&issuer=ApexMoto&Co`;
    const QRCode = require('qrcode');
    const qrCodeUrl = await QRCode.toDataURL(otpauthURL);
    res.json({ qrCodeUrl });
  } catch (error) {
    console.error('QR code error:', error);
    res.status(500).json({ error: 'Failed to generate QR code' });
  }
});

app.post('/admin/verify-2fa', (req, res) => {
  const { code } = req.body;
  if (!req.session.user) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  const { verifyTOTPCode } = require('./services/2fa');
  const storedCode = req.session.temp2FACode;
  if (!storedCode) {
    return res.status(400).json({ error: '2FA code expired' });
  }
  if (verifyTOTPCode(code, storedCode)) {
    req.session.authenticated2FA = true;
    delete req.session.temp2FACode;
    res.json({ success: true, message: '2FA verified' });
  } else {
    res.status(400).json({ error: 'Invalid 2FA code' });
  }
});

// ============================================================
// ENABLE 2FA ROUTE
// ============================================================

app.post('/admin/enable-2fa', requireAdmin, async (req, res) => {
  const { code } = req.body;
  const secret = req.session.temp2FASecret;
  
  if (!secret) {
    return res.status(400).json({ error: 'Session expired. Please reload the page.' });
  }
  
  if (!code || code.toString().length !== 6) {
    return res.status(400).json({ error: 'Invalid code format' });
  }
  
  try {
    const { verifyTOTPCode, enable2FA } = require('./services/2fa');
    
    const isValid = verifyTOTPCode(code, secret);
    
    if (!isValid) {
      return res.status(400).json({ error: 'Invalid code. Try again.' });
    }
    
    enable2FA(db, req.session.user.id, secret, (err) => {
      if (err) {
        console.error('2FA database error:', err);
        return res.status(500).json({ error: 'Failed to save 2FA' });
      }
      
      delete req.session.temp2FASecret;
      req.session.user.totp_enabled = 1;
      
      res.json({ success: true, message: '2FA enabled!' });
    });
  } catch (error) {
    console.error('2FA error:', error);
    res.status(500).json({ error: error.message });
  }
});

// ============================================================
// 2FA ENDPOINTS
// ============================================================

app.get('/admin/enable-2fa', (req, res) => {
  if (!req.session.user) return res.redirect('/login');
  const { generateTOTPSecret } = require('./services/2fa');
  const QRCode = require('qrcode');
  const secret = generateTOTPSecret();
  req.session.temp2FASecret = secret;
  const otpauthURL = `otpauth://totp/ApexMoto&Co:${req.session.user.email}?secret=${secret}&issuer=ApexMoto&Co`;
  QRCode.toDataURL(otpauthURL, (err, qrCode) => {
    if (err) return res.render('admin/enable-2fa', { qrCode: null, secret });
    res.render('admin/enable-2fa', { qrCode, secret });
  });
});

app.post('/admin/enable-2fa', requireAdmin, (req, res) => {
  const { code } = req.body;
  const secret = req.session.temp2FASecret;
  if (!secret || !code) return res.status(400).json({ error: 'Missing data' });
  db.run('UPDATE users SET totp_secret = ?, totp_enabled = 1 WHERE id = ?', [secret, req.session.user.id], (err) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    delete req.session.temp2FASecret;
    res.json({ success: true });
  });
});

// ============================================================
// 2FA ENDPOINTS
// ============================================================

app.get('/admin/enable-2fa', (req, res) => {
  if (!req.session.user) return res.redirect('/login');
  const { generateTOTPSecret } = require('./services/2fa');
  const QRCode = require('qrcode');
  const secret = generateTOTPSecret();
  req.session.temp2FASecret = secret;
  const otpauthURL = `otpauth://totp/ApexMoto&Co:${req.session.user.email}?secret=${secret}&issuer=ApexMoto&Co`;
  QRCode.toDataURL(otpauthURL, (err, qrCode) => {
    if (err) return res.render('admin/enable-2fa', { qrCode: null, secret });
    res.render('admin/enable-2fa', { qrCode, secret });
  });
});

app.post('/admin/enable-2fa', requireAdmin, (req, res) => {
  const { code } = req.body;
  const secret = req.session.temp2FASecret;
  if (!secret || !code) return res.status(400).json({ error: 'Missing data' });
  db.run('UPDATE users SET totp_secret = ?, totp_enabled = 1 WHERE id = ?', [secret, req.session.user.id], (err) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    delete req.session.temp2FASecret;
    res.json({ success: true });
  });
});

app.post("/admin/enable-2fa", requireAdmin, (req, res) => {
  const code = req.body.code;
  const secret = req.session.temp2FASecret;
  if (!secret || !code) return res.status(400).json({ error: "Missing data" });
  db.run("UPDATE users SET totp_secret = ?, totp_enabled = 1 WHERE id = ?", [secret, req.session.user.id], (err) => {
    if (err) return res.status(500).json({ error: "Database error" });
    delete req.session.temp2FASecret;
    res.json({ success: true });
  });
});

// ============================================================
// CHATBOT API
// ============================================================

function getChatbotReply(message) {
  const normalizedMessage = message.trim().toLowerCase();

  if (/\b(hello|hi|hey|hiya)\b/.test(normalizedMessage)) {
    return {
      reply: 'Hi! I’m the ApexMoto&Co assistant. I can help with our store, detailing, servicing, events or booking a service.',
      suggestions: ['What services do you offer?', 'How do I book?', 'Where is the store?']
    };
  }

  if (/\b(book|booking|appointment|schedule)\b/.test(normalizedMessage)) {
    return {
      reply: 'You can request a motorcycle service or detailing appointment through our booking form.',
      link: { label: 'Book a service', href: '/detailing/booking' },
      suggestions: ['What services do you offer?', 'How can I contact you?']
    };
  }

  if (/\b(detail|detailing|clean|valet|polish)\b/.test(normalizedMessage)) {
    return {
      reply: 'We offer premium motorcycle detailing and vehicle-care services. View the available treatments and request a booking online.',
      link: { label: 'View detailing', href: '/detailing' },
      suggestions: ['How do I book?', 'Do you offer servicing?']
    };
  }

  if (/\b(service|servicing|maintenance|repair|mechanic|motorcycle)\b/.test(normalizedMessage)) {
    return {
      reply: 'ApexMoto&Co provides basic motorcycle servicing and routine maintenance. Our team can assess your bike and advise on the right service.',
      link: { label: 'View servicing', href: '/services' },
      suggestions: ['How do I book?', 'How can I contact you?']
    };
  }

  if (/\b(store|shop|merch|product|buy|purchase)\b/.test(normalizedMessage)) {
    return {
      reply: 'Browse ApexMoto&Co products in our online store. Add items to your cart and check out securely.',
      link: { label: 'Visit the store', href: '/store' },
      suggestions: ['Do you offer servicing?', 'How can I contact you?']
    };
  }

  if (/\b(event|ride|community|competition|competitions)\b/.test(normalizedMessage)) {
    return {
      reply: 'We run motorcycle lifestyle events and community activities. Check the events page for the latest details.',
      link: { label: 'See events', href: '/events' },
      suggestions: ['Where is the store?', 'How can I contact you?']
    };
  }

  if (/\b(contact|email|phone|reach|address|location|where)\b/.test(normalizedMessage)) {
    return {
      reply: 'For general, store, events, detailing or servicing enquiries, send us a message through the contact page.',
      link: { label: 'Contact us', href: '/contact' },
      suggestions: ['What services do you offer?', 'How do I book?']
    };
  }

  return {
    reply: 'I can help with our store, motorcycle detailing, servicing, events and bookings. Try asking about one of those, or contact our team for a specific question.',
    suggestions: ['What services do you offer?', 'How do I book?', 'Visit the store']
  };
}

app.post('/api/chat', chatbotLimiter, validateCSRF, (req, res) => {
  const message = typeof req.body.message === 'string' ? req.body.message.trim() : '';

  if (!message || message.length > 500) {
    return res.status(400).json({
      error: 'Please enter a message of 1 to 500 characters.'
    });
  }

  return res.json(getChatbotReply(message));
});

// ============================================================
// API - SHOPIFY PRODUCTS
// ============================================================

app.get('/api/shopify-products', async (req, res) => {
  try {
    const shopify = require('./services/shopify');
    const products = await shopify.getProducts();
    
    if (products && products.length > 0) {
      const items = products.map(product => ({
        id: product.id,
        name: product.title,
        description: product.bodyHtml || product.title,
        price: parseFloat(product.variants[0]?.price || 0),
        available: product.variants.some((variant) => variant.available),
        category: product.productType || 'Uncategorized',
        image: product.images[0]?.src || '/images/placeholder.jpg',
        shopify_id: product.id
      }));
      res.json({ success: true, items });
    } else {
      res.json({ success: true, items: [] });
    }
  } catch (error) {
    console.error('Error fetching Shopify products:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

app.get('/api/shopify-featured-product', async (req, res) => {
  try {
    const shopify = require('./services/shopify');
    const product = await shopify.getPublicProduct('apex-core-hoodie');
    res.json({ success: true, product });
  } catch (error) {
    console.error('Error fetching featured Shopify product:', error.message);
    res.status(502).json({ success: false, error: 'Shopify product unavailable' });
  }
});

// ============================================================
// SHOPIFY STORE ROUTES
// ============================================================

app.use('/store', storeRoutes);

// 404 HANDLER
// ============================================================
//
// IMPORTANT:
// This MUST be the final route/middleware.
// Nothing should be added after this section except
// the server startup below.
//


// ============================================================
// INACTIVE ACCOUNT MANAGEMENT
// ============================================================

function checkAndDisableInactiveAccounts() {
  const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString();
  
  db.run(
    `UPDATE users SET is_active = 0 WHERE last_activity < ? AND is_active = 1`,
    [thirtyDaysAgo],
    function(err) {
      if (err) {
        console.error('Error disabling inactive accounts:', err.message);
      } else if (this.changes > 0) {
        console.log(`Disabled ${this.changes} inactive accounts`);
      }
    }
  );
}

function updateUserActivity(userId) {
  db.run(
    `UPDATE users SET last_activity = CURRENT_TIMESTAMP WHERE id = ?`,
    [userId],
    (err) => {
      if (err) console.error('Error updating user activity:', err.message);
    }
  );
}

// Run inactive check every hour
setInterval(checkAndDisableInactiveAccounts, 60 * 60 * 1000);

// Also run on startup
setTimeout(() => {
  checkAndDisableInactiveAccounts();
}, 2000);

// ============================================================
// USER PROFILE ROUTES
// ============================================================

const profileUpload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => {
      const dir = path.join(__dirname, 'public', 'uploads', 'profiles');
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      cb(null, dir);
    },
    filename: (req, file, cb) => {
      const user = req.session.user;
      const ext = path.extname(file.originalname);
      cb(null, `profile-${user.id}-${Date.now()}${ext}`);
    }
  }),
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (!file.mimetype.startsWith('image/')) {
      return cb(new Error('Only image files allowed'));
    }
    cb(null, true);
  }
});

app.get('/profile', requireLogin, (req, res) => {
  res.render('profile', { user: req.session.user });
});

app.post('/profile/update', requireLogin, profileUpload.single('profilePicture'), (req, res) => {
  const { displayName, email } = req.body;
  const user = req.session.user;
  
  if (displayName && displayName.length < 4) {
    return res.json({ success: false, message: 'Display name must be at least 4 characters' });
  }
  
  let query = 'UPDATE users SET display_name = ?, email = ?';
  let params = [displayName || null, email];
  
  if (req.file) {
    query += ', profile_picture = ?';
    params.push(`/uploads/profiles/${req.file.filename}`);
  }
  
  query += ' WHERE id = ?';
  params.push(user.id);
  
  db.run(query, params, function(err) {
    if (err) {
      console.error('Profile update error:', err);
      return res.json({ success: false, message: 'Error updating profile' });
    }
    
    user.display_name = displayName || user.username;
    user.email = email;
    if (req.file) {
      user.profile_picture = `/uploads/profiles/${req.file.filename}`;
    }
    req.session.user = user;
    
    res.json({ success: true, message: 'Profile updated successfully' });
  });
});

app.post('/profile/change-password', requireLogin, (req, res) => {
  const { currentPassword, newPassword } = req.body;
  const user = req.session.user;
  
  if (!currentPassword || !newPassword) {
    return res.json({ success: false, message: 'All fields are required' });
  }
  
  if (newPassword.length < 8) {
    return res.json({ success: false, message: 'Password must be at least 8 characters' });
  }
  
  db.get('SELECT password FROM users WHERE id = ?', [user.id], (err, userRecord) => {
    if (err || !userRecord) {
      return res.json({ success: false, message: 'User not found' });
    }
    
    bcrypt.compare(currentPassword, userRecord.password, (err, isMatch) => {
      if (err || !isMatch) {
        return res.json({ success: false, message: 'Current password is incorrect' });
      }
      
      bcrypt.hash(newPassword, 10, (err, hashedPassword) => {
        if (err) {
          return res.json({ success: false, message: 'Error hashing password' });
        }
        
        db.run('UPDATE users SET password = ? WHERE id = ?', [hashedPassword, user.id], (err) => {
          if (err) {
            return res.json({ success: false, message: 'Error updating password' });
          }
          
          res.json({ success: true, message: 'Password changed successfully' });
        });
      });
    });
  });
});


app.use((req, res) => {

  res.status(404).render(
    'error',
    {
      code: 404,
      message: 'Page not found'
    }
  );

});

// ============================================================
// START SERVER
// ============================================================

const PORT =
  process.env.PORT || 3000;

app.listen(
  PORT,
  () => {

    console.log(
      `ApexMoto&Co running on port ${PORT}`
    );

    console.log(
      `Admin Panel: http://localhost:${PORT}/admin`
    );

    console.log(
      `Detailing: http://localhost:${PORT}/detailing`
    );



  }
);