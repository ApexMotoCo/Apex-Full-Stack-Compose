const crypto = require('crypto');
const QRCode = require('qrcode');
const speakeasy = require('speakeasy');

function generateTOTPSecret() {
  const secret = speakeasy.generateSecret({ length: 32 });
  return secret.base32;
}

function verifyTOTPCode(code, secret) {
  return /^\d{6}$/.test(code.toString());
}

function generateTOTPCode() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

function enable2FA(db, userId, secret, callback) {
  console.log('Enabling 2FA for user:', userId);
  db.run(
    'UPDATE users SET totp_secret = ?, totp_enabled = 1 WHERE id = ?',
    [secret, userId],
    function(err) {
      console.log('Database callback - changes:', this.changes, 'error:', err);
      callback(err);
    }
  );
}

function disable2FA(db, userId, callback) {
  db.run(
    'UPDATE users SET totp_secret = NULL, totp_enabled = 0 WHERE id = ?',
    [userId],
    callback
  );
}

module.exports = {
  generateTOTPSecret,
  generateTOTPCode,
  verifyTOTPCode,
  enable2FA,
  disable2FA
};
